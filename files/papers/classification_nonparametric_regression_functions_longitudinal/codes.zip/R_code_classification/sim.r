
# Simulation of data (as described in Section 5)
# ----------------------------------------------


# generate regressors X

X.mat <- runif(n*T)
X.mat <- matrix(X.mat,ncol=n)

X <- list()
for(i in 1:n)
   X[[i]] <- X.mat[,i]  


# generate error terms

sd.eps  <- 1.3
eps.mat <- rnorm(n*T,mean=0,sd=sd.eps) 
eps.mat <- matrix(eps.mat,ncol=n)


# generate g-functions

theta <- function(u){(1-u^2)^4 *((sign(1-u^2)+1)/2)}

g1 <- function(u){0*u}
g2 <- function(u){1-2*u}
g3 <- function(u){0.75*atan(10*(u-0.6))}
g4 <- function(u){2.5*theta((u-0.75)/0.8) - 0.75}
g5 <- function(u){1.75*atan(5*(u-0.6)) + 0.75}


# define group lengths

n2 <- ceiling(n/4)  
n3 <- ceiling(n/6)  
n4 <- ceiling(n/12)  
n5 <- ceiling(n/12)  
n1 <- n-n2-n3-n4-n5

nk.vec <- c(0,n1,n1+n2,n1+n2+n3,n1+n2+n3+n4,n1+n2+n3+n4+n5)                 


# generate Y-observations

Y.mat <- matrix(0,ncol=n,nrow=T)

for(k in 1:K)
{  for(i in (nk.vec[k]+1):nk.vec[k+1])
   {  g.mat <- cbind(g1(X.mat[,i]),g2(X.mat[,i]),g3(X.mat[,i]),g4(X.mat[,i]),g5(X.mat[,i]))
      Y.mat[,i] <- g.mat[,k] + eps.mat[,i]
   }
}

Y <- list()
for(i in 1:n)
   Y[[i]] <- Y.mat[,i]  



