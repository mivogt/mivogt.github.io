
# Estimation of the L2-distances Delta
# ------------------------------------


Delta <- matrix(0,ncol=n,nrow=n)   # estimates of the L2-distances
m.hat <- matrix(0,ncol=n,nrow=N)   # Nadaraya-Watson estimates of the functions m_i; the i-th column contains the estimate of m_i

for(i in 1:n)
   m.hat[,i] <- m.i.hat(X[[i]],Y[[i]],bw,N)
  
for(i in 1:(n-1))
{  for(j in (i+1):n)
   {  int1 <- 0.5 * sum((m.hat[1:(N-1),i] - m.hat[1:(N-1),j])^2 * weight[1:(N-1)])/N
      int2 <- 0.5 * sum((m.hat[2:N,i] - m.hat[2:N,j])^2 * weight[2:N])/N
      if(scaling == "no")
        Delta[i,j] <- int1 + int2      
      if(scaling == "yes")
        Delta[i,j] <- (int1 + int2) / Bias[i,j]
      Delta[j,i] <- Delta[i,j]
   }
}





