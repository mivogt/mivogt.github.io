
# Calculation of the threshold level tau as described in Section 4.1
# ------------------------------------------------------------------


# calculation of the bias and variance expressions in equation (4.1)

Bias <- matrix(0,ncol=n,nrow=n)
Var  <- matrix(0,ncol=n,nrow=n)

dens  <- matrix(0,ncol=n,nrow=N)   # kernel estimates of the densities f_i; the i-th column contains the estimate of f_i
resid <- matrix(0,ncol=n,nrow=T)   # estimated residuals; the (i,t)-th element is the estimate of the error epsilon_(it) 
sigma <- rep(0,n)                  # error variance; the i-th entry is the estimate of the error variance E[epsilon_(it)]

for(i in 1:n)
{  dens[,i]  <- f.hat(X[[i]],bw,N)  
   resid[,i] <- resid.hat(X[[i]],Y[[i]],bw,N)
   sigma[i]  <- var(resid[,i])
}

int.b <- rep(0,n)   
for(i in 1:n)
   int.b[i] <- int.bias(dens[,i],N)

for(i in 1:n)
{   for(j in i:n)
    {  Bias[i,j] <- kappa0 * (sigma[i]*int.b[i] + sigma[j]*int.b[j])
       if(j > i)
         Bias[j,i] <- Bias[i,j]
    }
}

int.v <- matrix(0,ncol=n,nrow=n)  
for(i in 1:n)
{  for(j in i:n)
   {  int.v[i,j] <- int.var(dens[,i],dens[,j],N)
      if(j > i)
        int.v[j,i] <- int.v[i,j] 
   }
}

for(i in 1:n)
{  for(j in i:n)
   {  Var[i,j]  <- kappa1 * (2 * sigma[i]^2 * int.v[i,i] + 4 * sigma[i] * sigma[j] * int.v[i,j] + 2 * sigma[j]^2 * int.v[j,j]) 
      if(scaling == "yes")
        Var[i,j] <- Var[i,j] / Bias[i,j]^2 
      if(j > i)
        Var[j,i] <- Var[i,j]
   }
}

for(i in 1:n)
{  Bias[i,i] <- 0
   Var[i,i]  <- 0
}

Bias <- as.vector(Bias)
q.b <- quantile(Bias,0.95)
Bias[Bias > q.b] <- q.b
Bias <- matrix(Bias,ncol=n,nrow=n)

Var <- as.vector(Var)
q.v <- quantile(Var,0.95)
Var[Var > q.v] <- q.v
Var <- matrix(Var,ncol=n,nrow=n)


# calculation of threshold level tau

tau <- function(p)
{  if(scaling == "no")
     thres <- max(Bias)/(T*bw) + (sqrt(max(Var))/(T*bw^(1/2))) * (2*log(p))^(1/2)
   if(scaling == "yes")
     thres <- 1/(T*bw) + (sqrt(max(Var))/(T*bw^(1/2))) * (2*log(p))^(1/2)
   return(thres)
}




