
cat("","\n")
g.print <- list()
cat("Groups (thresholding approach):","\n")
for(k in 1:K.hat)
{  g.print[[k]] <- c("Group ",k,": ",groups.th[[k]])
   cat(g.print[[k]],"\n")
}

cat("","\n")
g.print <- list()
cat("Groups (k-means approach):","\n")
for(k in 1:K.hat)
{  g.print[[k]] <- c("Group ",k,": ",groups.km[[k]])
   cat(g.print[[k]],"\n")
}


x.plot <- (1:N)/N
dev.new(width=15,height=10)
par(mfrow=c(2,K.hat))
for(k in 1:K.hat)
{  g.vec <- groups.th[[k]]
   plot(x.plot,m.hat[,g.vec[1]],type="l",ylim=c(min(m.hat),max(m.hat)),xlab="",ylab="")
   if(length(g.vec) > 1)
   { for(i in 2:length(g.vec))
        lines(x.plot,m.hat[,g.vec[i]])
     lines(x.plot,g.fct[,k],col="red",lwd=1.5)
   }     
} 
mtext("Groups (thresholding approach)", outer=TRUE, line=-3, cex = 1)  
for(k in 1:K.hat)
{  g.vec <- groups.km[[k]]
   plot(x.plot,m.hat[,g.vec[1]],type="l",ylim=c(min(m.hat),max(m.hat)),xlab="",ylab="")
   if(length(g.vec) > 1)
   { for(i in 2:length(g.vec))
        lines(x.plot,m.hat[,g.vec[i]])
     lines(x.plot,g.fct[,k],col="red",lwd=1.5)
   }     
}  
mtext("Groups (k-means approach)", outer=TRUE, line=-41, cex = 1)  



