
# Estimation of the groups by the thresholding algorithm from Section 2.2
# -----------------------------------------------------------------------


group.fct <- function(S,Delta,p)

# the function estimates the class G to which some index i belongs given the index set S;
# the index i is chosen as described in Section 4.2
#
# arguments:
# S       index set, subset of {1,...,n} 
# Delta   n times n matrix of the L2-distances; the (i,j)-th entry is the estimate of Delta_(i,j) 
# p       argument of the threshold tau(p) as defined in equation (4.3) of the paper
#
# output: list with the following elements
# g       estimated group, or more exactly, vector of the indices belonging to the estimated group
# rest    elements of S not belonging to the estimated group g
# loop    = 0 if rest is empty and = 1 if rest is non-empty

{   len <- length(S)
 
    if(len == 1)
    { group    <- S
      rest     <- "empty"
      new.loop <- 0 
    }

    if(len > 1)
    { Delta <- Delta[S,S]
    
      # Calculate index i as described in Section 4.2

      max.jump <- rep(0,len)
      for(index in 1:len)      
      {  Delta.ordered <- sort(Delta[,index])
         p.hat         <- sum(Delta.ordered <= tau(p))
         if(p.hat < len)
           max.jump[index] <- Delta.ordered[p.hat+1] - Delta.ordered[p.hat]        
         if(p.hat == len)
           max.jump[index] <- 4*Delta.ordered[len]
      }       
      index <- which.max(max.jump)

      # Estimate the group G to which index belongs

      pos.ordered   <- S[order(Delta[,index])]
      Delta.ordered <- sort(Delta[,index])
      p.hat         <- sum(Delta.ordered <= tau(p))
 
      group <- sort(pos.ordered[1:p.hat])

      if(p.hat < len)
        rest <- sort(pos.ordered[(p.hat+1):len])
      if(p.hat == len)
        rest <- "empty"   

      if(p.hat < len)
        new.loop <- 1
      if(p.hat == len)
        new.loop <- 0  
    }

    list(g=group,rest=rest,loop=new.loop)
}


# iterative estimation algorithm (i.e., iterative application of the function "group.fct()" as described at the end of Section 2.2) 

S         <- 1:n     # initial value for the index set S
p         <- n       # initial value for the argument p of tau(p) as defined in equation (4.3)
k.pos     <- 1       # counts the number of iterations
new.loop  <- 1       # 1 = do another iteration step, 0 = stop the algorithm 
groups.th <- list()  # list of the estimated groups

while(new.loop == 1)
{  result <- group.fct(S,Delta,p)
   groups.th[[k.pos]] <- result$g
   S <- result$rest
   p <- max(1,length(S))
   new.loop <- result$loop
   k.pos <- k.pos + 1   
}

groups <- groups.th  # list of estimated groups
K.hat  <- k.pos - 1  # estimated number of groups K


# preparation for the additional k-means clustering step:
# compute vector "mship" of length n which indicates to which group each index belongs;
# if the i-th entry of "mship" has the value k, then the index i belongs to the k-th estimated group

mship.th <- rep(0,n)
for(i in 1:n)
{  for(k in 1:K.hat)
   {  g.temp <- groups.th[[k]]
      if(length(g.temp[g.temp==i]) == 1)  
        mship.th[i] <- k  
   }
}

mship <- mship.th



