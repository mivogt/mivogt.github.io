
# Estimation of the groups by the k-means clustering algorithm from Section 2.3
# -----------------------------------------------------------------------------


k.means <- function(m.hat,centres,K)

# the function performs one step of the k-means algorithm given cluster means "centres"
#
# arguments:
# m.hat     Nadaraya-Watson estimates of the functions m_i; N times n matrix whose i-th column is the estimate of m_i
# centres   cluster means; N times K matrix whose k-th column is the cluster mean of the k-th group
# K         number of groups
#
# output: list with the elements
# g             estimated groups; list with K elements 
# mship         vector of length n which indicates to which group each index belongs;
#               if the i-th entry of "mship" has the value k, then the index i belongs to the k-th estimated group
# empty.group   = 1 if one of the estimated groups is empty, = 0 otherwise

{  n <- dim(m.hat)[2]
   N <- dim(m.hat)[1]
   g <- list() 

   if(K == 1)
   { g[[1]] <- 1:n
     mship  <- rep(1,n)
     empty.group <- 0
   }

   if(K > 1)
   { g.vec <- rep(0,n)
  
     for(i in 1:n)
     {  dist <- rep(0,K) 
        for(k in 1:K)
        {  temp1 <- 0.5 * sum((m.hat[1:(N-1),i] - centres[1:(N-1),k])^2 * weight[1:(N-1)])/N
           temp2 <- 0.5 * sum((m.hat[2:N,i] - centres[2:N,k])^2 * weight[2:N])/N
           dist[k] <- temp1 + temp2
        }
        k0 <- which.min(dist)
        g.vec[i] <- k0
     }
     mship <- g.vec

     g.len <- rep(0,K)
     for(k in 1:K)
        g.len[k] <- length(g.vec[g.vec<=k])
          
     g.vec <- order(g.vec)
  
     g[[1]] <- g.vec[1:g.len[1]]
     for(k in 2:K)
        g[[k]] <- g.vec[(g.len[k-1]+1):g.len[k]]
   
     len.diff    <- g.len[2:K] - g.len[1:(K-1)]
     empty.group <- 0
     if(sum(len.diff == 0) > 0 | g.len[1] == 0)
       empty.group <- 1
   }

   list(g=g,mship=mship,empty.group=empty.group)
}


# k-means algorithm, i.e, iterative application of the function "k.means()"

loops    <- 0
new.loop <- 1
while(new.loop == 1)

{  centres   <- matrix(0,ncol=K.hat,nrow=N)
   mship.old <- mship
   
   for(k in 1:K.hat)
   {  if(length(groups[[k]]) == 1)
        centres[,k] <- m.hat[,groups[[k]]]
      if(length(groups[[k]]) > 1)
        centres[,k] <- rowMeans(m.hat[,groups[[k]]])  
   }

   res    <- k.means(m.hat,centres,K.hat)
   groups <- res$g
   mship  <- res$mship

   if(res$empty.group == 1)
   { groups <- groups.th
     mship  <- mship.th
     print("Empty group produced by k-means clustering!")
   }
   
   if(sum(abs(mship - mship.old)) == 0 | loops > 20)
     new.loop <- 0

   loops <- loops + 1
}


groups.km <- groups
mship.km  <- mship

