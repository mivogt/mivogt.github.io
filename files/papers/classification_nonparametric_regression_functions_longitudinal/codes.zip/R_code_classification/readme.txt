
We provide the R-code for the methods developed in Vogt and Linton,
"Classification of nonparametric regression functions in longitudinal 
data models". 

The code computes the threshold and k-means estimators from Section 2 
of the paper for the simulation setup of Section 5. 

The R-code consists of the following files: 

"main.r"              main file to run the code
"sim.r"               simulates a sample of data from the simulation design 
                      of Section 5 
"fcts.r"              defines the functions needed to perform the methods 
                      of the paper
"threshold.r"         computes the threshold level tau as explained in 
                      Section 4.1 of the paper
"Delta.r"             computes the L2-distances Delta
"groups_threshold.r"  performs the thresholding algorithm from Section 2.2
"groups_kmeans.r"     performs the k-means algorithm from Section 2.3
"g_fcts.r"            estimates the group-specific regression functions
                      as described in Section 2.4
"results.r"           summarizes and plots the estimation results


