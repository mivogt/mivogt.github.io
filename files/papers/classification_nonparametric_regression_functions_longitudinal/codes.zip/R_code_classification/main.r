rm(list=ls())


K  <- 5      # number of groups/classes
n  <- 120    # cross section dimension
T  <- 150    # time series dimension
bw <- 0.25   # bandwidth for NW estimators of m_i
N  <- 100    # grid length for the estimation of the functions m_i,
             # the functions are estimated on the grid 1/N, 2/N, ..., 1

weight  <- rep(1,N)   # weight function pi 
scaling <- "yes"      # "no"   work with L2-distances Delta as defined at the beginning of Section 2.2
                      # "yes"  work with scaled L2-distances as defined in Section 4.5


# Simulation of data

source("sim.r")
  

# Estimation

source("fcts.r")
source("threshold.r")
source("Delta.r")
source("groups_threshold.r")
source("groups_kmeans.r")
source("g_fcts.r")

  
# Results

source("results.r")

