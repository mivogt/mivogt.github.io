
# Definition of functions
# -----------------------


# Epanechnikov kernel

epan <- function(x)
{  return(0.75*(1-x^2)*((sign(1-x^2)+1)/2))}


# boundary correction for density estimation as described at the end of Section 4.1

b.correct <- function(x,bw)
{  lower <- -x/bw
   upper <- (1-x)/bw
   steps <- (upper-lower)/99
   grid  <- seq(lower,upper,by=steps) 
   temp1 <- epan(grid[1:(length(grid)-1)])
   temp2 <- epan(grid[2:length(grid)])
   return(0.5*sum(temp1+temp2)*steps)
}


# NW estimator of m_i (computed on the grid 1/N, 2/N, ..., 1)

m.i.hat <- function(X,Y,bw,N) 
{  m.vec <- rep(0,N)
   for(j in 1:N)
   {  rh <- sum(epan((X-j/N)/bw) * Y) 
      fh <- sum(epan((X-j/N)/bw))
      m.vec[j] <- rh/fh
   }
   return(m.vec)
}


# boundary corrected kernel density estimator (computed on the grid 1/N, 2/N, ..., 1)

f.hat <- function(X,bw,N) 
{  f.vec <- rep(0,N)
   for(j in 1:N)
      f.vec[j] <- sum(epan((X-j/N)/bw)) / (T*bw*b.correct(j/N,bw)) 
   return(f.vec)
}


# estimated residuals 

resid.hat <- function(X,Y,bw,N)
{  grid   <- (1:N)/N
   m.data <- approx(grid,m.i.hat(X,Y,bw,N),X,rule=2)$y
   resid  <- Y - m.data
   return(resid)
}


# auxiliary functions for computing the asymptotic bias and variance expressions from Section 4.1

grid   <- seq(-1,1,1/100)
kappa0 <- sum(epan(grid)^2)/100
temp   <- rep(0,length(grid)-1)
for(j in 1:(length(grid)-1))
   temp[j] <- sum(epan(grid) * epan(grid + grid[j]))/100
kappa1 <- sum(temp^2)/100

int.bias <- function(f.i,N)
{  f.i[f.i < 10^(-4)] <- 10^(-4) 
   int <- 0.5 * (sum(weight[1:(N-1)]/f.i[1:(N-1)]) + sum(weight[2:N]/f.i[2:N])) / N
   return(int)
}

int.var <- function(f.i,f.j,N)
{  f.i[f.i < 10^(-4)] <- 10^(-4)
   f.j[f.j < 10^(-4)] <- 10^(-4) 
   int1 <- sum(weight[1:(N-1)]^2/(f.i[1:(N-1)]*f.j[1:(N-1)])) 
   int2 <- sum(weight[2:N]^2/(f.i[2:N]*f.j[2:N]))
   int  <- 0.5 * (int1 + int2) / N
   return(int)
}

