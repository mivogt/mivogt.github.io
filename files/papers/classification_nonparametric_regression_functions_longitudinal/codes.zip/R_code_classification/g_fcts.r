
# Estimation of the group specific regression functions g_k as described in Section 2.4
# -------------------------------------------------------------------------------------


g.fct <- matrix(0,nrow=N,ncol=K.hat)

for(k in 1:K.hat)
{  if(length(groups[[k]]) == 1)
      g.fct[,k] <- m.hat[,groups[[k]]]
   if(length(groups[[k]]) > 1)
      g.fct[,k] <- rowMeans(m.hat[,groups[[k]]])
}

