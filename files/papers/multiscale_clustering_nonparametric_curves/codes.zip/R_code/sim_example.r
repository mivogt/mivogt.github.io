
# This file generates a sample of simulated data.  
# The simulation design is the same as in Section 7.1 of the paper.


# generate regressors X

X.mat <- matrix(0,ncol=n,nrow=T)
for(i in 1:n) X.mat[,i] <- runif(T)


# generate error terms

if(AR_par == "minus") a1 <- -0.25
if(AR_par == "plus")  a1 <- 0.25

sd.eps  <- 1                            # standard deviation of error terms
sd.eta  <- sqrt(sd.eps^2 * (1 - a1^2))  # standard deviation of innovation terms

burn    <- 50
eps.mat <- matrix(0,ncol=n,nrow=T+burn)                       # matrix of error terms
eta.mat <- matrix(rnorm(n*(T+burn),mean=0,sd=sd.eta),ncol=n)  # matrix of innovation terms

for(i in 1:n)
{  for(t in 2:(T+burn))
      eps.mat[t,i] <- a1 * eps.mat[t-1,i] + eta.mat[t,i]
}      
eps.mat <- eps.mat[(burn+1):(T+burn),]


# generate g-functions

biweight <- function(u,u0,h)
{ arg <- (u - u0)/h 
  val <- (1-arg^2)^2 *((sign(1-arg^2)+1)/2)
  return(val)
}

g1 <- function(u) 0*u
g2 <- function(u){0.35*biweight(u,0.25,0.25)}  
g3 <- function(u){0.35*biweight(u,0.75,0.25)} 
g4 <- function(u){2*biweight(u,0.25,0.025)} 
g5 <- function(u){2*biweight(u,0.75,0.025)} 

g.list <- list()
g.list[[1]] <- g1
g.list[[2]] <- g2
g.list[[3]] <- g3
g.list[[4]] <- g4
g.list[[5]] <- g5


# generate Y-observations

Y.mat <- matrix(0,ncol=n,nrow=T)

for(k in 1:K0)
{  i.min <- (k-1)*ceiling(n/K0)+1
   i.max <- min(k*ceiling(n/K0),n)
   for(i in i.min:i.max)
   {  g.mat <- g.list[[k]](X.mat[,i])
      Y.mat[,i] <- g.mat + eps.mat[,i]
   }
}


# define data

X <- list()
Y <- list()
for(i in 1:n)
{  X[[i]] <- X.mat[,i]
   Y[[i]] <- Y.mat[,i]   
}


# specify true groups

g.true <- rep(1:K0,rep(ceiling(n/K0),K0))  

