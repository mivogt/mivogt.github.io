
multiclust <- function(Y, X, x.grid, bw.grid, n_K="auto", alpha=0.05, Nsim=100, dendro=FALSE){


# Function performing the multiscale clustering 
#
# Inputs: 
#
# Y          List of n vectors Y[[1]],...,Y[[n]].
#            The i-th vector Y[[i]] is the time series { Y_it: t = 1,...T }. 
# X          List of n vectors X[[1]],...,X_[[n]].
#            The i-th vector X[[i]] is the time series { X_it: t = 1,...T }. 
#            NOTE: The X[[i]] time series must be normalized to have support 
#            in the unit interval [0,1] for each i.
# x.grid     Grid vector of location points. 
#            The grid points must lie in the unit interval [0,1]. 
# bw.grid    Grid vector of bandwidths. 
# n_K        Estimate number of groups? 
#            If yes, set n_K = "auto", otherwise specify number of groups, 
#            e.g. n_K = 5.
# alpha      "Significance level" to compute threshold pi as described in 
#            Algorithm 5.1 of the paper. Default is alpha = 0.05.
# Nsim       Number of simulation runs used in Algorithm 5.1. 
#            Default is Nsim = 100. 
# dendro     If TRUE, a dendrogram of the clustering results is plotted, 
#            if FALSE, no dendrogram is produced.  
#
# Output: 
#
# A list with the components 
# groups     Vector g of length n specifying the estimated group memberships. 
#            Example: Say we have n = 5 time series i = 1,...,5 and we get 
#            the output vector g = (2,1,2,3,1). This means that the first 
#            time series belongs to group 2, the second one to group 1, etc., 
#            the number of groups being equal to 3.   
# number     Number of (estimated or pre-specified) groups.            


# check whether operating system is Windows or Linux/MacOS

op.system <- Sys.info()[1]  
      

# determine length T and number n of time series

Tvec.X <- lengths(X)
Tvec.Y <- lengths(Y) 
n.X    <- length(Tvec.X)
n.Y    <- length(Tvec.Y)

if(n.X != n.Y) stop("Error: Number of X time series differs from number of Y time series!")
if(sum(Tvec.X != Tvec.Y) > 0) stop("Error: Y and X time series have different lengths!")

Tvec <- Tvec.X
n    <- n.X


# compute threshold pi to estimate number of groups 
# (only needed when n_K = "auto")

library(MASS)
if(n_K == "auto")
{ if(op.system == "Windows")
  { dyn.load("Functions/cov_fct.dll")  
    dyn.load("Functions/sup_sim.dll")  
  }
  if(op.system == "Linux")
  { dyn.load("Functions/cov_fct.so")  
    dyn.load("Functions/sup_sim.so")  
  }
  if(op.system != "Windows" & op.system != "Linux")
  { dyn.load("Functions/cov_fct_macOS.so")  
    dyn.load("Functions/sup_sim_macOS.so")  
  }
  source("Functions/cov_fct.r")
  source("Functions/sup_sim.r")
  source("Functions/thres_fct.r")   
  thres <- thres.fct(x.grid, bw.grid, 1-alpha, Nsim, add.correct="yes")  
}
  

# Estimation of unknown group structure

# compute multiscale distances d_ij for i,j = 1,...,n
if(op.system == "Windows")
  dyn.load("Functions/multiscale_statistic.dll")  
if(op.system == "Linux")
  dyn.load("Functions/multiscale_statistic.so")  
if(op.system != "Windows" & op.system != "Linux")
  dyn.load("Functions/multiscale_statistic_macOS.so")  
source("Functions/multiscale_statistic.r")

cat("Computing multiscale distance statistics (This may take a bit)","\n")
dists <- multiscale_stat(Y, X, Tvec, n, x.grid, bw.grid, add.correct="yes")  
dists <- as.dist(dists)

# run HAC clustering algorithm on multiscale distances d_ij
cat("Running the HAC clustering algorithm","\n")
res <- hclust(dists,method="complete")
if(n_K != "auto")
  g.hat <- cutree(res,k=n_K)
if(n_K == "auto")
  g.hat <- cutree(res,h=thres)
K0.hat <- max(g.hat)


# Return results

if(dendro == TRUE)
{ dev.new()
  plot(res,hang=-1,labels=FALSE,xlab="")
  if(n_K == "auto")
    abline(h=thres,lty=1.5,col="red")
}

return(list(groups=g.hat,number=K0.hat))

}





