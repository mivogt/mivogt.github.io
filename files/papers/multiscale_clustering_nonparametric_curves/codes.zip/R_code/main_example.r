rm(list=ls())


# This file runs the R code for a simulated example.
# The simulation design is the same as in Section 7.1 of the paper.
# On a "standard" computer, the code should take between 2 and 3
# minutes to run through.


# Specify parameters for simulation

n  <- 100   # number of time series
T  <- 1000  # time series length
K0 <- 5     # true number of groups

bw.grid <- seq(0.025,0.25,by=0.025)  # grid of bandwidths
x.grid <- seq(0.05,0.95,by=0.01)     # grid of locations

AR_par <- "minus"  # specify AR parameter for simulated error terms 
                   # "minus" gives AR parameter = -0.25
                   # "plus" gives AR parameter = 0.25   


# Simulate data

set.seed(1)
source("sim_example.r")


# Run main function "multiclust" which performs the multiscale clustering methods.
# (For a description of the function "multiclust", see the file "MultiClust.r")

source("MultiClust.r")
results <- multiclust(Y, X, x.grid, bw.grid, n_K="auto", dendro=TRUE)
g.hat   <- results$groups   # estimated groups 
K0.hat  <- results$number   # (estimated or pre-specified) number of groups


# Present estimation results

cat("","\n")
cat("Estimated groups:","\n")
cat(g.hat,"\n")

cat("","\n")
cat("Estimated number of groups:","\n")
cat(K0.hat,"\n")
cat("","\n")
