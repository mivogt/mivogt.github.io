
The R-code implements the multiscale clustering methods developed in 
Vogt and Linton, "Multiscale clustering of nonparametric regression 
curves". The code consists of the following files: 

(1) "main_example.r" runs the R-code for a simulated example. 
    The simulation design is as in Section 7.1 of the paper. 
    On a "standard" computer, the code should take between 2 
    and 3 minutes to run through.
   
(2) "sim_example.r" produces the simulated data which are used
    in "main_example.r".

(3) "MultiClust.r" contains the main R-function "multiclust" which 
    implements the multiscale clustering methods of the paper. A 
    description of the function with its inputs and outputs can be 
    found at the beginning of the file "MultiClust.r". 

(4) The subfolder "Functions" contains several auxiliary R-functions
    which are called by the main function "multiclust". (Some of 
    these functions are based on C-code which is called via the 
    dynamic libraries with the file extension .so (for Linux and 
    MacOS) and .dll (for Windows) that are included in the folder.) 


