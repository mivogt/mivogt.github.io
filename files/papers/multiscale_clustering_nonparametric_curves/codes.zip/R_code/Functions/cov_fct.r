cov.matrix <- function(u.GRID, h.GRID)

{   # Computes covariance matrix needed to simulate the threshold level for the estimation of K0 
    #
    # Input:
    # u.GRID  grid of locations (expanded version)
    # h.GRID  grid of bandwidths (expanded version)
    #
    # Output: 
    # N x N covariance matrix with N = length(u.GRID) = length(h.GRID)

    GRID.len <- as.integer(length(u.GRID))

    storage.mode(u.GRID) <- "double"
    storage.mode(h.GRID) <- "double"   
 
    cov.mat <- vector(mode="double",length=GRID.len*GRID.len)
  
    result <- .C("cov_matrix", u.GRID, h.GRID, GRID.len, cov.mat)
    res <- matrix(result[[4]],ncol=GRID.len,nrow=GRID.len)
    res <- res + t(res) + diag(0.5,GRID.len)
    return(res)
}
     