
#include <math.h> 
#include <R.h>
#include <Rmath.h> 
#include <stdlib.h> 
#include <stdio.h>


double awert(double x){

	/* This function provides the absolute value of a double x */

	if (x < 0)
	   return(-x);
	else
	   return(x);
}


double epanc(double x){

	/* This function calculates the value of the Epanechnikov kernel at point x */

	if (x > 1 || x < -1)
	   return(0.0);
	else
	   return (3.0 / 4.0) * (1 - x * x);
}


double m_ll(double y_data[], double x_data[], int T, double u, double h){

	/* Local linear estimator at location u and scale h */

	int t;
	double result, nom, denom, weight, arg, S1, S2;
        nom = 0;
        denom = 0;
	weight = 0;
        S1 = 0;	
        S2 = 0;

	for (t = 0; t < T; t++){
	    arg = ( u - x_data[t] ) / h;
            S1 += epanc(arg)*arg;
            S2 += epanc(arg)*arg*arg;
        }
        S1 = S1 / (float)T / h;
        S2 = S2 / (float)T / h;

	for (t = 0; t < T; t++){
	    arg = ( u - x_data[t] ) / h;
	    weight = epanc(arg) * (S2 - arg * S1);
            nom += weight * y_data[t]; 
            denom += weight; 
        }

        result = nom/denom;
	return(result);
}


double dens(double x_data[], int T, double u, double h){

	/* Boundary corrected kernel density estimator at location u and scale h */

        int t, len;
	double result, correct, arg, step;
	result = 0;
        len = 200; 

        correct = 1;

        if (-u/h > -1.0){
           correct = 0;
           step = (1 + u/h) / (float)len;           
           for (t = 0; t < len; t++){
               arg = -u/h + t*step;
               correct += epanc(arg)*step;
           }    
        }

        if ((1-u)/h < 1.0){
           correct = 0;
           step = ((1-u)/h + 1)/ (float)len;           
           for (t = 0; t < len; t++){
               arg = -1 + t*step;
               correct += epanc(arg)*step;
           }    
        }
             
	for (t = 0; t < T; t++){
	    arg = ( u - x_data[t] ) / h;
            result += epanc(arg);
        }
        result = result / (float)T / h / correct;
        return(result);
}


double sigma(double y_data[], double x_data[], int T, double h){

	/* Estimator of error variance */

        int t, len;
	double resid, result;
	result = 0;
        len = 0;

        for (t = 0; t < T; t++){
	    resid = 0;
	    if (x_data[t] >= 0 && x_data[t] <= 1){
               resid = y_data[t] - m_ll(y_data, x_data, T, x_data[t], h); 
               result += resid*resid;
               len++;
            } 	  
        }
        result = result / (float)len;
        return(result);      
}        


double ker_scaling(double u, double h){

	/* Kernel constant for scaling of the psi statistics */

        int t, len;
        double result, kappa0, kappa1, kappa2, arg, step;
        kappa0 = 0;
        kappa1 = 0;
        kappa2 = 0;
        len = 200; 

	result = 0;
        step = 2.0 / (float)len;
        for (t = 0; t < len; t++){
            arg = -1 + t*step;
            result += epanc(arg)*epanc(arg)*step;
        }

        if (-u/h > -1.0){
  	   result = 0;
           step = (1 + u/h) / (float)len;           
           for (t = 0; t < len; t++){
               arg = -u/h + t*step;
               kappa0 += epanc(arg)*step;
               kappa1 += epanc(arg)*arg*step;
               kappa2 += epanc(arg)*arg*arg*step;
           }  
           for (t = 0; t < len; t++){
               arg = -u/h + t*step;
	       result += epanc(arg) * epanc(arg) * (kappa2 - kappa1*arg) * (kappa2 - kappa1*arg) * step; 
           }
           result = result / (kappa0*kappa2 - kappa1*kappa1) / (kappa0*kappa2 - kappa1*kappa1);        
        }

        if ((1-u)/h < 1.0){
  	   result = 0;
           step = ((1-u)/h + 1) / (float)len;           
           for (t = 0; t < len; t++){
               arg = -1 + t*step;
               kappa0 += epanc(arg)*step;
               kappa1 += epanc(arg)*arg*step;
               kappa2 += epanc(arg)*arg*arg*step;
           }
           for (t = 0; t < len; t++){
               arg = -1 + t*step;
    	       result += epanc(arg) * epanc(arg) * (kappa2 - kappa1*arg) * (kappa2 - kappa1*arg) * step; 
           }   
           result = result / (kappa0*kappa2 - kappa1*kappa1) / (kappa0*kappa2 - kappa1*kappa1);        
        }   
        
        return(result);
}


void multiscale_stat(double *y_data, double *x_data, int *Tvec, int *Tmax, int *n, double *u_grid, double *h_grid, int *u_len, int *h_len, double *correct, double *d_mat){
      
        /* y_data    Y-observations Y = (Y_11, ..., Y_1T, Y_21, ..., Y_2T, ...) , vector of length n*T
           x_data    X-observations X = (X_11, ..., X_1T, X_21, ..., X_2T, ...) , vector of length n*T
           Tvec      time series lengths, vector of length n
           Tmax      maximal time series length
           n         number of subjects
           u_grid    grid points in x-direction, vector of length u_len
           h_grid    grid points in h-direction, vector of length h_len
           u_len     length of u_grid     
           h_len     length of h_grid
           correct   vector of additive correction terms, vector of length h_len
           d_mat     vector of length n x n containing the values of the multiscale statistics
       */

        int i, j, k, l, t, pos;
        double arg, m_diff, scaling, stat_temp, maximum;
        double *y_vec, *x_vec, *c_vec, *m_vec, *dens_vec, *sigma_vec, *ker_scale;
             
        y_vec = (double*) malloc(sizeof(double) * Tmax[0]);
        x_vec = (double*) malloc(sizeof(double) * Tmax[0]); 
        c_vec = (double*) malloc(sizeof(double) * n[0]);
        m_vec = (double*) malloc(sizeof(double) * n[0] * u_len[0]);
        dens_vec = (double*) malloc(sizeof(double) * n[0] * u_len[0]);
        sigma_vec = (double*) malloc(sizeof(double) * n[0]);
        ker_scale = (double*) malloc(sizeof(double) * u_len[0]);
  
        for (i=0; i < n[0]*n[0]; i++)
            d_mat[i] = 0;        

    
        for (k=0; k < h_len[0]; k++){

            for (l=0; l < u_len[0]; l++)
	        ker_scale[l] = ker_scaling(u_grid[l],h_grid[k]);

            pos = 0;  

            for (i=0; i < n[0]; i++){
	        for (t=0; t < Tvec[i]; t++){
	            y_vec[t] = y_data[pos+t]; 
                    x_vec[t] = x_data[pos+t]; 
                }
                for (l=0; l < u_len[0]; l++){
                    m_vec[i*u_len[0] + l] = m_ll(y_vec, x_vec, Tvec[i], u_grid[l], h_grid[k]);
                    dens_vec[i*u_len[0] + l] = dens(x_vec, Tvec[i], u_grid[l], h_grid[k]); 
	        }
                sigma_vec[i] = sigma(y_vec, x_vec, Tvec[i], h_grid[k]); 
                c_vec[i] = (float)Tvec[i] / (float)Tmax[0];
	        pos += Tvec[i];
            }

	    for (i=0; i < n[0]-1; i++){
	        for (j=i+1; j < n[0]; j++){
	            for (l=0; l < u_len[0]; l++){              
		        m_diff = sqrt((float)Tmax[0] * h_grid[k]) * (m_vec[i*u_len[0] + l] - m_vec[j*u_len[0] + l]); 
                        scaling = ( sigma_vec[i] / c_vec[i] / dens_vec[i*u_len[0] + l] + sigma_vec[j] / c_vec[j] / dens_vec[j*u_len[0] + l] ) * ker_scale[l];
                        stat_temp = awert(m_diff / sqrt(scaling)) - correct[k];
         	        if (l == 0)
    		           maximum = stat_temp;
                        if (l > 0 && stat_temp > maximum)
    		           maximum = stat_temp;    	                
                    }
                    if (k == 0)
  	               d_mat[i*n[0]+j] = maximum;               
               	    if (k > 0 && maximum > d_mat[i*n[0]+j])
    		       d_mat[i*n[0]+j] = maximum;    	            
		}
            } 
        }


        free(m_vec);
        free(dens_vec);   
        free(sigma_vec);     
        free(c_vec);
        free(x_vec);
        free(y_vec);
        free(ker_scale);
}
         


