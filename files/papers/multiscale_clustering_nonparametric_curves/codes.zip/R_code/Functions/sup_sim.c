#include <math.h> 
#include <Rinternals.h> 
#include <R.h>
#include <stdlib.h> 
#include <Rmath.h>


double awert(double x)
{   if(x < 0) 
       return(-x);
    else
       return(x);
}


void sup_sim(double *Zeta, int *N, int *len, double *correct, double *bound1, double *bound2)

{   /* Zeta       matrix of N simulated normal random vectors of length len 
                  (stacked in a long vector) 
       N, len     see above 
       correct    vector of additive correction terms, length = len
       bound1     bound for computing threshold level (without additive correction)
       bound2     bound for computing threshold level (with additive correction) */

    /* Definition and initializing of some variables */
  
    int i, j, k, l;
    double temp1, temp2;
        
    temp1 = 0.0; 
    temp2 = 0.0;
    bound1[0] = 0.0;
    bound2[0] = 0.0;

    /* Compute bounds for threshold */

    for(i=0; i < N[0]-1; i++)
    {   for(j=i+1; j < N[0]; j++)
        {  for(k=0; k < len[0]; k++)
	   {   temp1 = awert(Zeta[k + i*len[0]] - Zeta[k + j*len[0]]);
	       if(temp1 > bound1[0])
                  bound1[0] = temp1;
               temp2 = awert(Zeta[k + i*len[0]] - Zeta[k + j*len[0]]) - correct[k];
	       if(temp2 > bound2[0])
                  bound2[0] = temp2;
           }
        }
    }
}     
             

  

