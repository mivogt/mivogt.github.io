
thres.fct <- function(u.grid, h.grid, alpha, Nsim, add.correct)


{   # function to compute the threshold level for the estimation of K0
    #  
    # Input:
    # u.grid       grid of location points 
    # h.grid       grid of bandwidths
    # alpha        significance level
    # Nsim         number of simulation runs
    # add.correct  additive correction: "yes" or "no"
    #
    # Output:
    # bound1       bound (without additive correction) to compute threshold level
    # bound2       bound (with additive correction) to compute threshold level


    # Step 1: compute vectorized grid and additive correction term

    GRID     <- expand.grid(u.grid,h.grid)
    u.GRID   <- GRID[,1]
    h.GRID   <- GRID[,2]
    GRID.len <- dim(GRID)[1]
    correct  <- sqrt(2*log(1/(2*h.GRID)))  # additive correction term


    # Step 2: compute covariance structure

    Cov.mat <- cov.matrix(u.GRID, h.GRID) 
    
    eig <- eigen(Cov.mat,symmetric=TRUE)
    eigvals <- eig$values
    eigvecs <- eig$vectors
    if(eigvals[GRID.len] <= 10^(-6))
    { eigvecs <- eigvecs[, eigvals > 10^(-6)]
      eigvecs <- as.matrix(eigvecs)
      eigvals <- eigvals[eigvals > 10^(-6)]  
    }

    Cov.mat <- eigvecs %*% diag(eigvals) %*% t(eigvecs)


    # Step 3: compute normal approximations with covariance structure from above

    Bounds  <- matrix(0,nrow=2,ncol=Nsim)
    
    cat("","\n")
    cat("Computing threshold pi","\n")
    progbar <- txtProgressBar(min = 1, max = Nsim, style = 3, char = ".")

    for(nb in 1:Nsim)
    {  Zeta <- t(mvrnorm(n, mu=rep(0,GRID.len), Sigma=Cov.mat))
       bnds <- sup.sim(Zeta, correct)
       Bounds[1,nb] <- bnds$bound1
       Bounds[2,nb] <- bnds$bound2

       setTxtProgressBar(progbar, nb)
    }
    close(progbar)
    
    # Step 4: compute threshold level

    if(add.correct == "no")
      thres <- quantile(Bounds[1,], alpha)
    if(add.correct == "yes")
      thres <- quantile(Bounds[2,], alpha)

    return(thres)
}
