sup.sim <- function(Zeta, correct)

{   # Zeta     matrix of simulated Gaussian vectors
    # correct  vector of additive corrections

    N   <- as.integer(dim(Zeta)[2])
    len <- as.integer(dim(Zeta)[1])
    
    if(len != length(correct))
      stop("Incompatible lengths of simulated vectors for the estimation of K0!")

    Zeta <- as.vector(Zeta)
   
    storage.mode(Zeta)    <- "double"
    storage.mode(correct) <- "double"   
 
    bound1 <- vector(mode="double",length=1)
    bound2 <- vector(mode="double",length=1)

    result <- .C("sup_sim", Zeta, N, len, correct, bound1, bound2)
    
    list(bound1=result[[5]], bound2=result[[6]]) 
}
     