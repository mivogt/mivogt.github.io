
#include <math.h> 
#include <R.h>
#include <Rmath.h> 
#include <stdlib.h> 
#include <stdio.h>


double epanc(double x){

	/* This function calculates the value of the Epanechnikov kernel at point x */

	if (x > 1 || x < -1)
	   return(0.0);
	else
	   return (3.0 / 4.0) * (1 - x * x);
}


double cov_val(double u, double u_prime, double h, double h_prime){

	/* Computes entry Cov(u,u_prime,h,h_prime) of covariance matrix needed to simulate 
           the threshold level for the estimation of K0 */

        int t, len;
        double arg, kappa0, kappa1, kappa2, kappa0_prime, kappa1_prime, kappa2_prime; 
	double result, K_sq, K_sq_prime, nom, denom, temp, temp_prime; 
        kappa0 = 0;
        kappa1 = 0;
        kappa2 = 0;
        K_sq = 0;
        temp = 0;
        kappa0_prime = 0;
        kappa1_prime = 0;
        kappa2_prime = 0;
        K_sq_prime = 0;
        temp_prime = 0;
        nom = 0;
        denom = 0;
        result = 0;
        len = 250; 

        for (t = 0; t < (2*len); t++){
            arg = (float)t / (float)len - 1.0; 
            if (arg > -u/h && arg < (1-u)/h){
               kappa0 += epanc(arg);
               kappa1 += epanc(arg)*arg;
               kappa2 += epanc(arg)*arg*arg;
            }
        }
        kappa0 = kappa0 / (float)len;
        kappa1 = kappa1 / (float)len;
        kappa2 = kappa2 / (float)len;

        for (t = 0; t < (2*len); t++){
            arg = (float)t / (float)len - 1.0; 
            if (arg > -u_prime/h_prime && arg < (1-u_prime)/h_prime){
               kappa0_prime += epanc(arg);
               kappa1_prime += epanc(arg)*arg;
               kappa2_prime += epanc(arg)*arg*arg;
            }
        }
        kappa0_prime = kappa0_prime / (float)len;
        kappa1_prime = kappa1_prime / (float)len;
        kappa2_prime = kappa2_prime / (float)len;

        for (t = 0; t < (2*len); t++){
            arg = (float)t / (float)len - 1.0; 
            if (arg > -u/h && arg < (1-u)/h){
	       K_sq += epanc(arg) * epanc(arg) * (kappa2 - kappa1*arg) * (kappa2 - kappa1*arg);
            }
        }
        K_sq = K_sq / (float)len;

        for (t = 0; t < (2*len); t++){
            arg = (float)t / (float)len - 1.0; 
            if (arg > -u_prime/h_prime && arg < (1-u_prime)/h_prime){
	       K_sq_prime += epanc(arg) * epanc(arg) * (kappa2_prime - kappa1_prime*arg) * (kappa2_prime - kappa1_prime*arg);
            }
        }
        K_sq_prime = K_sq_prime / (float)len;
     
        denom = 2 * sqrt(K_sq * K_sq_prime);

        for (t = 0; t < (2*len); t++){
            arg = (float)t / (float)len - 1.0; 
            if (arg > -u/h && arg < (1-u)/h){
 	       temp = epanc(arg) * (kappa2 - kappa1*arg);
               temp_prime = epanc( (h*arg + u - u_prime)/h_prime ) * (kappa2_prime - kappa1_prime * (h*arg + u - u_prime)/h_prime); 
               nom += temp*temp_prime;
            } 
        }
        nom = nom / (float)len;        
 
        result = sqrt(h/h_prime) * nom/denom;
        return(result); 
}
        

void cov_matrix(double* u_grid, double *h_grid, int *grid_len, double* cov_mat){

        /* Computes covariance matrix needed to simulate the threshold level for the 
           estimation of K0 

           u_grid     grid in x-direction (expanded version), vector of length grid_len
           h_grid     grid in h-direction (expanded version), vector of length grid_len
           grid_len   length of grid (expanded version)    
           cov_mat    covariance matrix (grid_len x grid_len)
       */

       int i, j;
    
       for (i = 0; i < grid_len[0]-1; i++){
	   for (j = i+1; j < grid_len[0]; j++){
	       cov_mat[i*grid_len[0]+j] = cov_val(u_grid[i], u_grid[j], h_grid[i], h_grid[j]);
           }
       }
}
