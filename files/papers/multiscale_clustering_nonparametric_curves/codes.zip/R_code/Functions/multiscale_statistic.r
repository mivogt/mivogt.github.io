multiscale_stat <- function(Y, X, Tvec, n, u.grid, h.grid, add.correct){

     # Inputs:
     # Y            y time series (list of length n)
     # X            x time series (list of length n)
     # Tvec         vector of time series lengths
     # n            number of subjects 
     # u.grid       grid of locations
     # h.grid       grid of bandwidths
     # add.correct  additive correction term: "yes" or "no"
     #
     # Output 
     # n x n matrix of multiscale statistics

     Tmax <- as.integer(max(Tvec))   
     storage.mode(Tvec) <- "integer"
     storage.mode(n) <- "integer"

     storage.mode(u.grid) <- "double"
     storage.mode(h.grid) <- "double"
     u.len <- as.integer(length(u.grid))
     h.len <- as.integer(length(h.grid))
   
     if(add.correct == "yes")
       h.correct <- sqrt(2 * log(1/(2*h.grid)))   
     if(add.correct == "no")
       h.correct <- rep(0,h.len)
     storage.mode(h.correct) <- "double"

     y.data <- numeric(0)
     x.data <- numeric(0)
     for(i in 1:n)
     {  y.data <- c(y.data,Y[[i]])
        x.data <- c(x.data,X[[i]])        
     }
     storage.mode(y.data) <- "double"
     storage.mode(x.data) <- "double"

     d.mat <- vector(mode="double",length=n*n) 
   
     result <- .C("multiscale_stat", y.data, x.data, Tvec, Tmax, n, u.grid, h.grid, u.len, h.len, h.correct, d.mat)
     res <- matrix(result[[11]],ncol=n,nrow=n)
     res <- res + t(res)
     return(res)
}

