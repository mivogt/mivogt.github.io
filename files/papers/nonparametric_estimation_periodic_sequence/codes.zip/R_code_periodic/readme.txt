
We provide the code for the methods developed in Vogt and Linton, 
"Nonparametric estimation of a periodic sequence in the presence
of a smooth trend"

(1) "estimator.r" is an R-function which implements the estimation
    methods of the paper.

(2) "data.example.r" applies the function "estimator.r" to the 
    data set of temperature anomalies used in the paper.

(3) "HADCRUT3.txt" contains the temperature data. The data set can 
    be downloaded from www.cru.uea.ac.uk/cru/data/temperature. 
    A detailed description of the data is given in Brohan, Kennedy, 
    Harris, Tett & Jones (2006) "Uncertainty estimates in regional 
    and global observed temperature changes: A new data set from 
    1850", Journal of Geophysical Research 111.
