
rm(list=ls())
source("estimator.r")


Y <- as.matrix(read.table("HADCRUT3.txt",header=FALSE))
## Yearly global temperature anomalies from 1850 to 2011.


results <- estimator(Y,bw=0.15)
period  <- results$period
m       <- results$m
g       <- results$g
crit    <- results$crit


print(paste("estimated period: ", period))

start  <- 1850
freq   <- 1
data   <- ts(Y,start=start,frequency=freq)
m.plot <- ts(m,start=start,frequency=freq)
g.plot <- ts(g,start=start,frequency=freq)

dev.new()
par(mfcol=c(2,2))
plot(data,type="l",ylab="",xlab="year",lwd=1.5,font.main=1,main="Temperature Anomalies")
plot(crit,type="l",ylab="",xlab="years",lwd=1.5,font.main=1,main="Criterion function")
plot(m.plot,type="b",ylab=expression(hat(m)),xlab="year",lwd=1.5,font.main=1,main="Estimator of the periodic component")
plot(g.plot,type="l",ylab=expression(hat(g)),xlab="year",lwd=1.5,font.main=1,main="Trend estimator")


