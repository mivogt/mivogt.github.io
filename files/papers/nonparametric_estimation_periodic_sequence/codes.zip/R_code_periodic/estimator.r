
estimator <- function(y,bw,kappa=log(T),theta.max=ceiling(T/2))


##  This function estimates the components of the model proposed by
##  Vogt and Linton (2012), "Nonparametric estimation of a periodic
##  sequence in the presence of a smooth trend"
##
##  Model: 
##  Y_t = m(t) + g(t) + eps_t, where m is a periodic component with
##  an unknown period theta0, g is a smooth trend function and eps_t is 
##  a stochastic error term. The goal is to estimate the period theta0
##  as well as the function values of m and g.
##
##  Inputs:
##  Y          a data vector of length T
##  bw         bandwidth for the estimation of the trend function
##  kappa      rate parameter of the penalty term, default is log(T)
##  theta.max  maximal candidate value for the period, default is
##             ceiling(T/2)
##
##  Outputs:
##  a list with the following elements    
##  period  estimate of the period theta0
##  m       estimate of the periodic component at each time point
##          1,...,T; a vector of length T
##  g       estimate of the trend function at each rescaled time point
##          1/T,2/T,...,1; a vector of length T 
##  crit    criterion function; vector of length theta.max     


{   T <- length(Y)   # sample size
       

    ## Definition of auxiliary functions
    ## ---------------------------------

    periodic.fct <- function(y,theta)

    ##  Inputs: 
    ##  y      data vector of length T
    ##  theta  candidate period 
    ##
    ##  Output:
    ##  function values of the periodic model component for  
    ##  the candidate period theta; vector of length T  

    {   if(theta == 1)
        {  m.theta <- rep(mean(y),T)    
           return(m.theta)      
        }
 
        if(theta > 1)
        {  # calculate design matrix
           X <- matrix(0,ncol=theta,nrow=theta*ceiling(T/theta))  
           x <- diag(theta)
           for(k in 1:theta)
               X[,k] <- rep(x[,k],ceiling(T/theta))
           X <- X[1:T,] 
 
           # calculate estimate  
      	   m.theta <- t(X) %*% y
      	   m.theta <- m.theta / rowSums(t(X))
      	   m.theta <- rep(m.theta,ceiling(T/theta))
      	   m.theta <- m.theta[1:T]

      	   return(m.theta)
        }
    }


    trend.fct <- function(z,bw)

    ##  Inputs: 
    ##  z   vector of length T; in what follows always the vector
    ##      of raw data minus the estimated periodic component
    ##  bw  bandwidth    
    ##
    ##  Output:
    ##  function values of the trend at all rescaled time points
    ##  1/T, 2/T, ..., 1; a vector of length T

    {   epan <- function(x){0.75*(1-x^2)*((sign(1-x^2)+1)/2)}  # Epanechnikov kernel
        fct  <- rep(0,T)

        for(t in 1:T)
        {   weight <- epan(((1:T)/T - t/T)/bw)
            reg    <- (1:T)/T - t/T
            fit    <- lm(z ~ reg,weights=weight)
            fct[t] <- as.double(fit$coef[1])
        }

        return(fct)
    }


    ## Calculate Residual Sum of Squares (RSS) for each candidate period
    ## -----------------------------------------------------------------

    RSS <- rep(0,theta.max) 
    for(theta in 1:theta.max)
        RSS[theta] <- sum((Y - periodic.fct(Y,theta))^2)


    ## Calculate sigma^2 parameter of the penalty term
    ## -----------------------------------------------

    theta.eps   <- which.min(RSS)
    m.theta.eps <- periodic.fct(Y,theta.eps)
    Y.eps       <- Y - m.theta.eps
    trend.eps   <- trend.fct(Y.eps,bw)
    eps.hat     <- Y.eps - trend.eps
    sigma.sq    <- var(eps.hat)  


    ## Estimate Period
    ## ---------------

    crit      <- RSS + sigma.sq * kappa * seq(1,theta.max,1)  # criterion function
    theta.hat <- which.min(crit)  


    ## Estimate periodic function
    ## --------------------------

    m.theta.hat <- periodic.fct(Y,theta.hat)  


    ## Estimate trend function
    ## -----------------------

    Z     <- Y - m.theta.hat
    trend <- trend.fct(Z,bw)

 
    return(list(period=theta.hat,m=m.theta.hat,g=trend,crit=crit))
 
}







  




