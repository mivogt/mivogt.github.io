rm(list=ls())
source("functions/auxiliary.R")
source("functions/data_sim.R")
source("functions/breslow.R")
source("fused_lasso.R")


# -------------------
# Model specification  
# -------------------

# The simulated model is a Cox model as defined in Setting B of 
# Rosenbaum, Beyersmann & Vogt (2024) with the following specifics:
#
# jumps       jump locations of piecewise constant hazard
# values      function values of piecewise constant hazard 
# censoring   type of right-censoring: one of the following 
#             "none" = no right-censoring
#             "exp" = right-censoring has exponential dist. with parameter 0.5
#             "uniform" = right-censoring has uniform dist. on [0,2.5]
# beta        parameter vector: 
#             either NULL if there are no covariates
#             or vector of length 2 if two covariates are included
#             (first covariate is binary and takes the values -1, 1 with prob 0.5 each,
#             second covariate is uniformly distributed on [-1,1])
# interval    interval where estimation takes place 
# n           number of data points in simulated sample

jumps     <- c(0.25)    
values    <- c(4,1)    
censoring <- "exp"        
beta      <- NULL   
interval  <- c(0,1)          
n         <- 1000             


# ------------------------------------
# Simulation of one sample of length n
# ------------------------------------

data   <- simulated.sample(n,values,jumps,censoring,beta)
events <- data$times  # right-censored event times (vector of length n)
delta  <- data$ind    # vector of censoring indicators (vector of length n):
                      # if i-th entry has value 0, then the i-th event time is censored
                      # if i-th entry has value 1, then the i-th event time is not censored
reg    <- data$reg    # regressor matrix (either NULL or n x 2 matrix depending
                      # on choice of beta)


# ---------------------------------------
# Estimation of piecewise constant hazard
# ---------------------------------------

res <- fused.lasso(events=events,delta=delta,interval=interval,reg=reg,
                   left.trunc=NULL,lambda="automatic",pilot=20,q.level=0.9,MC.loops=100)

grid <- res$grid            # grid of time points where hazard is estimated (vector of length n) 
hazard.hat <- res$fit       # estimated hazard values (vector of length n)  
jumps.hat <- res$jumps      # estimated jump locations / change points of hazard
heights.hat <- res$heights  # estimated jump heights


# --------------------------
# Plot of estimation results
# --------------------------

# true hazard and cumulative hazard
haz <- rep(NA,length(grid))
cum.haz <- rep(NA,length(grid))
for(i in 1:length(grid))
{  haz[i] <- hazard(grid[i],values,jumps)  
   cum.haz[i] <- cum.hazard(grid[i],values,jumps)
}    

# Breslow estimator 
t.vals <- sort(unique(events[delta==1]))
t.vals <- t.vals[1:sum(t.vals <= 1)]
Breslow.est <- Breslow.estimator(t.vals,events,delta,reg,left.trunc=NULL)

# summary plot
# left-hand plot: cumulative hazard (blue) and Nelson-Aalen / Breslow estimator (red)
# right-hand plot: hazard rate (blue) and fused lasso estimator (red)
dev.new()
par(mfcol=c(1,2),mar=c(4.5,4.5,1,1))
y.min <- 0
y.max <- max(c(cum.haz,Breslow.est))
plot(NULL,xlim=interval,ylim=c(y.min,y.max),xlab="time",ylab="cumulative hazard")
for(k in 1:length(jumps)) abline(v=jumps[k],col="darkgrey")  
lines(grid,cum.haz,type="l",col="blue")
lines(t.vals,Breslow.est,type="s",col="red")  
y.min <- min(c(haz,hazard.hat))
y.max <- max(c(haz,hazard.hat))
plot(grid,haz,type="l",col="blue",ylim=c(y.min,y.max),xlab="time",ylab="hazard")
lines(grid,hazard.hat,col="red")





