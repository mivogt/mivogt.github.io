rm(list=ls())
library(readxl)
library(colorspace)
library(latex2exp)
source("functions/auxiliary.R")
source("functions/breslow.R")
source("fused_lasso.R")


# ---------------------
# Read and prepare data
# ---------------------

data <- read_excel("data/OAK_Clinical_Data_short.xlsx")
data <- data[data$TRT01P == "MPDL3280A",]

OS <- data$OS    # overall survival times
PFS <- data$PFS  # progression free survival times

data.def <- function(transition)

## Reformulation of data as right-censored (and left-truncated) event times:
##
## Inputs:
## transition   "01", "02" or "12"   
##
## Output: for each transition, the data are expressed as a list with the following items:
## $events      a vector of right-censored event times  
## $delta       a vector of right-censoring indicators (1 = no censoring, 0 = censoring)
## $left        a vector of left-truncation times 
##              (only for 12 transition, == NULL for 01 and 02 transition)
  
{  diff.OS.PFS <- OS - PFS
   delta.OS <- as.numeric(data$OS.CNSR == 0)    # censoring indicator for OS
   delta.PFS <- as.numeric(data$PFS.CNSR == 0)  # censoring indicator for PFS
   
   if(transition == "01") 
   { events <- PFS  
     correction <- as.numeric(diff.OS.PFS == 0) * (as.numeric(data$OS.CNSR == 1) - as.numeric(data$PFS.CNSR == 1))  
     delta <- as.numeric(data$PFS.CNSR == 0) * (as.numeric(diff.OS.PFS > 0) + correction)
     left.truncation <- NULL
   }  
   if(transition == "02")
   { events <- PFS
     correction <- as.numeric(data$OS.CNSR == 1) - as.numeric(data$PFS.CNSR == 1)  
     delta <- (as.numeric(data$PFS.CNSR == 0) - correction) * as.numeric(diff.OS.PFS == 0) 
     left.truncation <- NULL
   }    
   if(transition == "12")
   { pos <- as.numeric(data$PFS.CNSR == 0) * as.numeric(diff.OS.PFS > 0) 
     events <- OS[pos==1]
     delta <- as.numeric(data$OS.CNSR[pos==1] == 0) 
     left.truncation <- PFS[pos==1]
   }
   return(list(events=events,delta=delta,left=left.truncation))
}


# --------------------------------
# Estimation of transition hazards
# --------------------------------

probs.min <- c(0.025)            # lower bounds of estimation interval (in increasing order), for 12-transition only
probs.max <- c(0.99,0.975,0.8)   # upper bounds of estimation interval (in decreasing order)
probs.lambda <- c(0.1,0.5,0.9)   # quantiles for lambda calibration

pos.trans <- 0                   
trans <- c(TeX("Transition $0 \\to 1$"),TeX("Transition $0 \\to 2$"),TeX("Transition $1 \\to 2$"))

for(transition in c("01","02","12"))
  
{  pos.trans <- pos.trans + 1

   # read data
   data.list <- data.def(transition)
   events <- data.list$events
   delta <- data.list$delta 
   left.truncation <- data.list$left

   # sample size
   n <- length(events)

   # bounds of interval for estimation
   int.min <- min(events[delta==1])
   if(transition == "12")
     int.min <- as.vector(quantile(events[delta==1],probs=probs.min))
   int.max <- as.vector(quantile(events[delta==1],probs=probs.max))

   # computation of Breslow estimator  
   t.vals <- sort(unique(events[delta==1]))
   if(transition == "01" | transition == "02")
     Breslow.est <- Breslow.estimator(grid=t.vals,events=events,delta=delta,reg=NULL,left.trunc=NULL)
   if(transition == "12")
     Breslow.est <- Breslow.estimator(grid=t.vals,events=events,delta=delta,reg=NULL,left.trunc=left.truncation)

   # computation of hazard estimators and reconstructed cumulative hazard 
   # for different intervals and different choices of lambda
   for(q.lambda in probs.lambda)
   {  results <- list()
      pos <- 1
      for(j.min in 1:length(int.min))
      {  for(j.max in 1:length(int.max))
         {  # estimate hazard rate
            interval <- c(int.min[j.min],int.max[j.max])
            res <- fused.lasso(events=events,delta=delta,interval=interval,reg=NULL,
                               left.trunc=left.truncation,lambda="automatic",
                               pilot=20,q.level=q.lambda,MC.loops=100)      
            hazard.hat <- res$fit
            values.hat <- unique(hazard.hat)
            jumps.hat <- res$jumps 
            grid <- res$grid
            # reconstruct cumulative hazard
            cumhaz.hat <- rep(NA,length(grid))
            for(k in 1:length(grid))
               cumhaz.hat[k] <- cum.hazard(grid[k],values.hat,jumps.hat)
            if(transition == "12")
            { start <- sum(t.vals - grid[1] <= 0)
              cumhaz.hat <- cumhaz.hat - cumhaz.hat[1] + Breslow.est[start]
            }  
            # store results
            results[[pos]] <- list(int=interval,
                                   grid=grid,
                                   haz=hazard.hat,
                                   jumps=jumps.hat,
                                   values=values.hat,
                                   cumhaz=cumhaz.hat)
            pos <- pos + 1
         }   
      }   
      assign(paste0("results_",transition,"_q",as.integer(100*q.lambda)),results)
   }  


# ------------
# Plot results
# ------------

   hazard.max <- 0
   for(q.lambda in probs.lambda)
   {  results <- get(paste0("results_",transition,"_q",as.integer(100*q.lambda)))
      for(pos in 1:(length(int.min)*length(int.max)))
         hazard.max <- max(hazard.max,max(results[[pos]]$haz)) 
   }
   legend.vec <- character()
   for(i in 1:length(probs.max))
      legend.vec[i] <- paste0("p = ",probs.max[i])
  
   dev.new()
   par(mfrow=c(length(probs.lambda),2),mar=c(4.5,4.5,3,1),font.main=1,cex.main=1,oma=c(0,0,2,0))
   cols <- c("red","blue","green4","brown4","magenta4","darkseagreen4",
             "firebrick2","blue4","palegreen4","indianred3","mediumpurple","olivedrab4")
   for(q.lambda in probs.lambda)
   {  results <- get(paste0("results_",transition,"_q",as.integer(100*q.lambda)))
      plot(NULL,xlim=c(t.vals[1],t.vals[length(t.vals)]),ylim=c(0,1.1*hazard.max),xlab="time (months)",ylab="hazard")
      title(main=paste0("q = ",q.lambda),line=1)
      for(pos in 1:(length(int.min)*length(int.max)))
      {  grid <- results[[pos]]$grid
         haz <- results[[pos]]$haz
         lines(grid,haz,col=cols[pos],lwd=1.2)
      }
      legend("topright",legend=legend.vec,col=cols[1:length(probs.lambda)],lty=1,lwd=1.2,bg="white")
      plot(t.vals,Breslow.est,type="s",xlab="time (months)",ylab="cumulative hazard",lwd=1.5,col="grey40")
      title(main=paste0("q = ",q.lambda),line=1)
      for(pos in 1:(length(int.min)*length(int.max)))
         lines(results[[pos]]$grid,results[[pos]]$cumhaz,col=cols[pos],lwd=1.2)
      legend("topleft",legend=legend.vec,col=cols[1:length(probs.lambda)],lty=1,lwd=1.2,bg="white")
   } 
   mtext(trans[pos.trans],side=3,line=0.5,outer=TRUE,cex=0.85)
}






