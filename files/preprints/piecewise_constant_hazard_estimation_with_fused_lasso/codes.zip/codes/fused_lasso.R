
fused.lasso <- function(events,delta,interval=NULL,reg=NULL,left.trunc=NULL,
                        lambda="automatic",pilot=20,q.level=0.9,MC.loops=100)

## compute fused lasso estimator of piecewise constant hazard
##  
## Inputs:
## events       vector of (possibly) right-censored event times (length n)
## delta        vector of censoring indicators (length n)  
## interval     interval where estimation takes place:
##              - either user-specified value of the form c(left,right) with
##                left / right = left / right endpoint of interval 
##              - or NULL, in which case interval = c(left,right) with
##                left  = min(events[delta==1]) if there is no left-truncation 
##                      = quantile(events[delta==1],probs=0.025) if there is left-truncation 
##                right = quantile(events[delta==1],probs=0.975)
## reg          regressor matrix: 
##              - either n times d matrix with each column corresponding to a specific regressor
##              - or NULL if there are no covariates  
## left.trunc   left truncation: 
##              - either vector of length n
##              - or NULL if there is no left-truncation 
## lambda       value of regularization parameter of the fused lasso:
##              - either user-specified value
##              - or "automatic", in which case lambda is computed in a data-
##                driven way with hyperparameters "pilot", "q.level", "MC.loops" 
##                (see Section 5 of Rosenbaum, Beyersmann & Vogt (2024))
## pilot         hyperparameter for "automatic" choice of lambda:
##               choice of initial lambda value as largest lambda value s.t. 
##               fused lasso has #jumps = pilot
## q.level       hyperparameter for "automatic" choice of lambda: 
##               quantile level 
## MC.loops      hyperparameter for "automatic" choice of lambda: 
##               number of Monte Carlo simulations
##  
## Output: list with elements
## $grid         vector of time points where fused lasso coefficients are computed
## $fit          vector of fused lasso coefficients  
## $jumps        jump locations    
## $heights      jump heights     
  
{  # required packages
   library(genlasso)
   library(survival)
  
   # required auxiliary functions
   source("functions/breslow.R")
   source("functions/lambda_choice.R")
  
   # sample size
   n <- length(events)  
  
   # baseline interval for estimation  
   if(is.null(interval))  
   { int.min <- min(events[delta==1])
     if(!is.null(left.trunc))
       int.min <- quantile(events[delta==1],probs=0.025)
     int.max <- quantile(events[delta==1],probs=0.975)
     interval <- c(int.min,int.max)
   }   

   # Breslow increments  
   grid <- seq(interval[1],interval[2],by=(interval[2] - interval[1])/n)
   Breslow.est <- Breslow.estimator(grid,events,delta,reg,left.trunc)
   Y <- (n/(interval[2]-interval[1])) * (Breslow.est[2:(n+1)] - Breslow.est[1:n])

   # choice of regularization parameter lambda
   if(lambda == "automatic")
     lambda <- lambda.choice(Y,pilot,q.level,MC.loops)
     
   # fused lasso fit with genlasso package (computes the whole solution path) 
   genlasso.fit <- fusedlasso1d(y=Y,pos=1:n)  
   genlasso.beta <- genlasso.fit$beta
   genlasso.lambda <- genlasso.fit$lambda

   # fused lasso fit for chosen lambda  
   lambda <- n*lambda/2  
   lambda.temp <- c(genlasso.lambda,lambda)
   pos <- which.max(lambda - lambda.temp >= 0) 
   if(pos < length(lambda.temp))
     alpha <- signif(genlasso.beta[,pos],5)
   if(pos == length(lambda.temp))   
     alpha <- signif(genlasso.beta[,pos-1],5)
   alpha <- as.vector(alpha)
   
   # jump points and jump heights
   alpha.diff <- diff(alpha)
   jump.nb <- sum(alpha.diff != 0)
   jump.locs <- numeric(0)
   jump.hghts <- numeric(0)
   if(jump.nb > 0)
   {  jump.hghts <- alpha.diff[alpha.diff != 0]
      jump.locs <- 2:n
      jump.locs <- jump.locs[alpha.diff != 0]
      jump.locs <- jump.locs * (interval[2] - interval[1])/n
   }   
 
   return(list(grid=grid[-1],fit=alpha,jumps=jump.locs,heights=jump.hghts))
}

