
lambda.choice <- function(Y,pilot,q.level,MC.loops)
  
## compute "optimal" lambda value
##
## Inputs:   
## Y             data vector
## pilot         choice of initial lambda: choose largest lambda s.t. 
##               fused lasso has #jumps = pilot
## q.level       quantile level 
## MC.loops      number of Monte Carlo simulations
##
## Outputs:
## lambda.val    computed lambda value

{  # required packages
   library(genlasso)
  
   # sample size
   n <- length(Y)

   # compute pilot lambda and corresponding model residuals
   genlasso.fit <- fusedlasso1d(y=Y,pos=1:n)  
   genlasso.beta <- genlasso.fit$beta
   alpha.pilot <- genlasso.beta[,pilot+1]
   resid <- Y - alpha.pilot 

   # compute effective noise
   effective.noise <- rep(NA,MC.loops)
   #prog.lambda <- progress_bar$new(total=MC.loops,clear=FALSE)
   #print(paste0("Progress of lambda calibration:"))
   for(loop in 1:MC.loops)
   {  noise  <- resid * rnorm(n)
      eff.noise <- rep(NA,n-1)
      for(j in 1:(n-1))
         eff.noise[j] <- abs(-(2/n) * sum(noise[1:j]) + (2*j/n^2) * sum(noise))
      effective.noise[loop] <- max(eff.noise)
      #prog.lambda$tick()
   }

   #compute quantile of effective noise 
   lambda.val <- as.numeric(quantile(effective.noise,q.level))

   return(lambda.val)  
}  

