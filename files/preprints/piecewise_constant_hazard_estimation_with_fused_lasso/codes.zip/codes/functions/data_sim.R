
simulated.sample <- function(n,values,jumps,censoring,beta)

## simulation of data sample  
##
## Inputs:
## n           number of data points in simulated sample     
## values      function values of piecewise constant hazard 
## jumps       jump locations of piecewise constant hazard
## censoring   type of right-censoring: one of the following 
##             "none" = no right-censoring
##             "exp" = right-censoring has exponential dist. with parameter 0.5
##             "uniform" = right-censoring has uniform dist. on [0,2.5]
## beta        parameter vector: 
##             either NULL if there are no covariates
##             or vector of length 2 if two covariates are included
##             (first covariate is binary and takes the values -1, 1 with prob 0.5 each,
##             second covariate is uniformly distributed on [-1,1])
## 
## Output: list with the components
## $times      right-censored event times (vector of length n)
## $ind        censoring indicator (vector of length n)
## $reg        n times d regressor matrix (with d = number of regressors)

{  uniform.draws <- runif(n)
   reg <- NULL
   if(!is.null(beta))   
   { reg1 <- sample(c(-1,1),n,replace=TRUE)
     reg2 <- runif(n,min=-1,max=1)
     reg <- cbind(reg1,reg2)
   }
   T.star <- rep(NA,n)
   for(i in 1:n)
   {  if(is.null(beta)) 
        T.star[i] <- inverse.dist.fct(uniform.draws[i],values,jumps)
      if(!is.null(beta))
      { values.i <- values * exp(beta[1]*reg1[i] + beta[2]*reg2[i])
        T.star[i] <- inverse.dist.fct(uniform.draws[i],values.i,jumps)
      }
   }    
   T.censored <- rep(NA,n)
   delta <- rep(0,n)
   if(censoring == "none")
     censor <- rep(2*max(T.star),n)
   if(censoring == "exp")
     censor <- rexp(n, rate = 0.5)
   if(censoring == "uniform")
     censor <- runif(n, min = 0, max = 2.5) 
   for(i in 1:n)
   {  T.censored[i] <- min(T.star[i],censor[i]) 
      if(T.star[i] <= censor[i])
        delta[i] <- 1
   }   
   return(list(times=T.censored,ind=delta,reg=reg))
}

