
## hazard function

hazard <- function(t,values,jumps)
{  number.jumps <- length(jumps)
   index <- 1
   for(k in 1:number.jumps)
   {  if(t >= jumps[k])
        index <- index+1
   }
   return(values[index])
}


## cumulative hazard function

cum.hazard <- function(t,values,jumps)
{  number.jumps <- length(jumps)
   if(length(jumps) == 0)
     res <- values[1]*t
   if(length(jumps) > 0)
   { tau <- c(0,jumps)
     interval.lengths <- tau[2:length(tau)] - tau[1:(length(tau)-1)]
     index <- 1
     for(k in 1:number.jumps)
     {  if(t > jumps[k])
          index <- index+1
     }
     if(index == 1)
       res <- values[1]*t
     if(index > 1)
       res <- sum(interval.lengths[1:(index-1)] * values[1:(index-1)]) + values[index]*(t-jumps[index-1])
   } 
   return(res)
}


## density of survival times

density.fct <- function(t,values,jumps)
{  res <- hazard(t,values,jumps) * exp(-cum.hazard(t,values,jumps))
   return(res)
}


## distribution function of survival times

dist.fct <- function(t,values,jumps)
{  res <- 1 - exp(-cum.hazard(t,values,jumps))
   return(res)
}


## inverse cumulative hazard

inverse.cum.hazard <- function(x,values,jumps)
{  # compute break points of inverse cumulative hazard
   number.jumps <- length(jumps)
   breaks <- rep(NA,number.jumps) 
   tau <- c(0,jumps,1)
   interval.lengths <- tau[2:length(tau)] - tau[1:(length(tau)-1)]
   for(k in 1:number.jumps)
      breaks[k] <- interval.lengths[1:k] %*% values[1:k]
   # check between which two break points x lies
   index <- 1
   for(k in 1:number.jumps)
   {  if(x >= breaks[k])
        index <- index+1
   }
   # compute value of inverse cumulative hazard at x
   if(index == 1)
     res <- x/values[index]
   if(index > 1)
     res <- (1/values[index]) * (x - breaks[index-1]) + jumps[index-1] 
   return(res)
}


## inverse distribution function of survival times   

inverse.dist.fct <- function(t,values,jumps)
{  x <- -log(1-t)
   res <- inverse.cum.hazard(x,values,jumps)
   return(res)
}


