
Breslow.estimator <- function(grid,events,delta,reg,left.trunc)
  
## compute Breslow estimator of cumulative hazard  
## 
## Inputs:
## grid         grid of time points where estimation should take place
## events       vector of censored event times
## delta        vector of censoring indicators
## reg          regressor matrix (NULL if there are no covariates, otherwise
##              n times d matrix with each column corresponding to a specific regressor)
## left.trunc   left truncation (NULL if there is no left truncation, otherwise
##              a vector of length n)  
##
## Outputs:
## Breslow      function values of Breslow estimator on grid    

{  # required packages
   library(survival)
  
   # sample size
   n <- length(events) 

   # sort events in increasing order and sort other variables accordingly
   pos <- order(events)
   events <- events[pos]
   delta <- delta[pos]
   
   # compute uncensored event times and ties 
   uc.vals <- events[delta==1]
   uc.ties <- as.vector(table(uc.vals))
   uc.vals <- unique(uc.vals)
   uc.n <- length(uc.vals)
   
   # define matrices needed to compute #(subjects at risk) and Z.bar
   events.mat <- matrix(rep(events,uc.n),nrow=uc.n,byrow=TRUE)
   uc.mat <- matrix(rep(uc.vals,n),nrow=uc.n,byrow=FALSE)
   if(!is.null(left.trunc))
   { left.trunc <- left.trunc[pos]
     left.mat <- matrix(rep(left.trunc,uc.n),nrow=uc.n,byrow=TRUE)  
   }   
   if(!is.null(reg))
   { reg <- reg[pos,]
     cox <- coxph(Surv(events,delta) ~ reg)
     beta.hat <- matrix(cox$coefficients,ncol=1)
     reg.part <- as.vector(exp(reg %*% beta.hat))
     reg.mat <- matrix(rep(reg.part,uc.n),nrow=uc.n,byrow=TRUE)
   }
  
   # compute #(subjects at risk) and Z.bar 
   if(is.null(left.trunc))
   { if(is.null(reg))
     { at.risk <- (uc.mat <= events.mat)
       Z.bar <- rowSums(at.risk)
     }   
     if(!is.null(reg))
     { at.risk <- (uc.mat <= events.mat)
       Z.bar <- rowSums(at.risk * reg.mat)
     }
   }
   if(!is.null(left.trunc))
   { if(is.null(reg))
     { at.risk <- (left.mat < uc.mat) * (uc.mat <= events.mat)
       Z.bar <- rowSums(at.risk)
     }
     if(!is.null(reg))
       stop("Cox regression with left truncation not available yet!")  
   }

   # compute Breslow estimator at jump points uc.vals 
   fct.vals <- cumsum(uc.ties/Z.bar)
   # compute Breslow estimator on grid
   Breslow <- approx(x=uc.vals,y=fct.vals,xout=grid,method="constant",rule=2)$y
   return(Breslow)
}   

